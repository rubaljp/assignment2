import java.util.ArrayList;
import java.util.List;

public class EmployeeRepo {
    private static EmployeeRepo instance = null;
    private List<Employees> employees= new ArrayList<>();

    private EmployeeRepo(){
        Employees one = new Employees();
        one.Fname = "Anuj";
        one.Lname = "Monga";
        one.Employeeid = "AnujMonga";
        one.Epswrd = 12345;
        this.employees.add(one);
    }

    public static EmployeeRepo getInstance(){
        if(instance == null){
            instance = new EmployeeRepo();
        }
        return instance;
    }

    public void addEmployee(Employees employee){
        this.employees.add(employee);
    }
    public List<Employees> getEmployees(){
        return this.employees;
    }
}
