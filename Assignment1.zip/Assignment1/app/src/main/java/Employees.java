public class Employees {
    String Fname ;
    String Lname ;
    String Employeeid ;
    int Epswrd ;
}
