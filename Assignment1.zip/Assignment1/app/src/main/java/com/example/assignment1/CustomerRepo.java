package com.example.assignment1;

import java.util.ArrayList;
import java.util.List;

public class CustomerRepo {
    private static CustomerRepo instance = null;
    private List<Customer> customers= new ArrayList<>();

    private CustomerRepo(){
        Customer one = new Customer();
        one.Fname = "jatinderpal";
        one.Lname = "singh";
        one.Username = "jp";
        one.Password = 12345;
        this.customers.add(one);
    }

    public static CustomerRepo getInstance(){
        if(instance == null){
            instance = new CustomerRepo();
        }
        return instance;
    }

    public void addCustomer(Customer customer){
        this.customers.add(customer);
    }
    public List<Customer> getCustomers(){
        return this.customers;
    }
}
