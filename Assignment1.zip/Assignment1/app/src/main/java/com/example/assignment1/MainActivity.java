package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView username = findViewById(R.id.username);
        final TextView password = findViewById(R.id.password);

        Button login = findViewById(R.id.login);

        TextView forgot = findViewById(R.id.forgot);
        TextView signup = findViewById(R.id.signup);
        TextView employee = findViewById(R.id.employee);

        final CustomerRepo repo = CustomerRepo.getInstance();


        final Intent intent = new Intent(MainActivity.this,ClientPage1.class);
        final Intent intent1 = new Intent(MainActivity.this,Employee.class);

        employee.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
            }
        });

        login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String Uname = username.getText().toString();
                int pswrd = Integer.parseInt(password.getText().toString());
                for(int i = 0; i<repo.getCustomers().size();i++){
                    if(Uname.equalsIgnoreCase(repo.getCustomers().get(i).Username)){
                        if(pswrd==repo.getCustomers().get(i).Password){
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Password is invalid", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Username is invalid", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}




