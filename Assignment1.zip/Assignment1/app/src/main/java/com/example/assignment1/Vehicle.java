package com.example.assignment1;

public class Vehicle {
    String manufacture;
    String model;
    Integer price;
}
