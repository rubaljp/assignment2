package com.example.assignment1;
//POJO

public class Customer {
    String Fname;
    String Lname;
    String Username;
    int Password;
}
